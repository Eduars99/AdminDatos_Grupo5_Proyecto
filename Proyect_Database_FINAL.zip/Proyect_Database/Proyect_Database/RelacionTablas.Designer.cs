﻿
namespace Proyect_Database
{
    partial class RelacionTablas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbLlave2 = new System.Windows.Forms.ComboBox();
            this.cmbLlave1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbTRelacion = new System.Windows.Forms.ComboBox();
            this.dgvResultados2 = new System.Windows.Forms.DataGridView();
            this.cmbTabla2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvResultados1 = new System.Windows.Forms.DataGridView();
            this.cmbTabla1 = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.crearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultaSQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnVisualizar = new System.Windows.Forms.Button();
            this.dgvRelaciones = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRelaciones)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.BackColor = System.Drawing.Color.SteelBlue;
            this.btnConfirmar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConfirmar.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmar.ForeColor = System.Drawing.Color.White;
            this.btnConfirmar.Location = new System.Drawing.Point(437, 159);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(171, 29);
            this.btnConfirmar.TabIndex = 27;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = false;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.label6.ForeColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(948, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 18);
            this.label6.TabIndex = 26;
            this.label6.Text = "Llave Foranea";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(300, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 18);
            this.label5.TabIndex = 25;
            this.label5.Text = "Llave Primaria";
            // 
            // cmbLlave2
            // 
            this.cmbLlave2.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.cmbLlave2.ForeColor = System.Drawing.Color.Black;
            this.cmbLlave2.FormattingEnabled = true;
            this.cmbLlave2.Location = new System.Drawing.Point(1073, 209);
            this.cmbLlave2.Name = "cmbLlave2";
            this.cmbLlave2.Size = new System.Drawing.Size(188, 26);
            this.cmbLlave2.TabIndex = 24;
            // 
            // cmbLlave1
            // 
            this.cmbLlave1.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.cmbLlave1.ForeColor = System.Drawing.Color.Black;
            this.cmbLlave1.FormattingEnabled = true;
            this.cmbLlave1.Location = new System.Drawing.Point(432, 209);
            this.cmbLlave1.Name = "cmbLlave1";
            this.cmbLlave1.Size = new System.Drawing.Size(176, 26);
            this.cmbLlave1.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(24, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 18);
            this.label4.TabIndex = 22;
            this.label4.Text = "Tipo de Relación:";
            // 
            // cmbTRelacion
            // 
            this.cmbTRelacion.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.cmbTRelacion.ForeColor = System.Drawing.Color.Black;
            this.cmbTRelacion.FormattingEnabled = true;
            this.cmbTRelacion.Items.AddRange(new object[] {
            "1:1",
            "1:N",
            "N:M"});
            this.cmbTRelacion.Location = new System.Drawing.Point(189, 162);
            this.cmbTRelacion.Name = "cmbTRelacion";
            this.cmbTRelacion.Size = new System.Drawing.Size(188, 26);
            this.cmbTRelacion.TabIndex = 21;
            // 
            // dgvResultados2
            // 
            this.dgvResultados2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados2.Location = new System.Drawing.Point(662, 256);
            this.dgvResultados2.Name = "dgvResultados2";
            this.dgvResultados2.RowHeadersWidth = 51;
            this.dgvResultados2.RowTemplate.Height = 24;
            this.dgvResultados2.Size = new System.Drawing.Size(577, 272);
            this.dgvResultados2.TabIndex = 20;
            // 
            // cmbTabla2
            // 
            this.cmbTabla2.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.cmbTabla2.ForeColor = System.Drawing.Color.Black;
            this.cmbTabla2.FormattingEnabled = true;
            this.cmbTabla2.Location = new System.Drawing.Point(739, 209);
            this.cmbTabla2.Name = "cmbTabla2";
            this.cmbTabla2.Size = new System.Drawing.Size(188, 26);
            this.cmbTabla2.TabIndex = 19;
            this.cmbTabla2.SelectedIndexChanged += new System.EventHandler(this.cmbTabla2_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(659, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 18);
            this.label3.TabIndex = 18;
            this.label3.Text = "Tabla 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(24, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 18);
            this.label2.TabIndex = 17;
            this.label2.Text = "Tabla 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 42.2F);
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(12, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(596, 90);
            this.label1.TabIndex = 16;
            this.label1.Text = "Relación entre Tablas";
            // 
            // dgvResultados1
            // 
            this.dgvResultados1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados1.Location = new System.Drawing.Point(27, 256);
            this.dgvResultados1.Name = "dgvResultados1";
            this.dgvResultados1.RowHeadersWidth = 51;
            this.dgvResultados1.RowTemplate.Height = 24;
            this.dgvResultados1.Size = new System.Drawing.Size(574, 273);
            this.dgvResultados1.TabIndex = 15;
            // 
            // cmbTabla1
            // 
            this.cmbTabla1.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.cmbTabla1.ForeColor = System.Drawing.Color.Black;
            this.cmbTabla1.FormattingEnabled = true;
            this.cmbTabla1.Location = new System.Drawing.Point(106, 209);
            this.cmbTabla1.Name = "cmbTabla1";
            this.cmbTabla1.Size = new System.Drawing.Size(188, 26);
            this.cmbTabla1.TabIndex = 14;
            this.cmbTabla1.SelectedIndexChanged += new System.EventHandler(this.cmbTabla1_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Georgia", 10F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crearToolStripMenuItem,
            this.consultaSQLToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1284, 28);
            this.menuStrip1.TabIndex = 28;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // crearToolStripMenuItem
            // 
            this.crearToolStripMenuItem.Name = "crearToolStripMenuItem";
            this.crearToolStripMenuItem.Size = new System.Drawing.Size(119, 24);
            this.crearToolStripMenuItem.Text = "Nueva Tabla";
            this.crearToolStripMenuItem.Click += new System.EventHandler(this.crearToolStripMenuItem_Click);
            // 
            // consultaSQLToolStripMenuItem
            // 
            this.consultaSQLToolStripMenuItem.Name = "consultaSQLToolStripMenuItem";
            this.consultaSQLToolStripMenuItem.Size = new System.Drawing.Size(127, 24);
            this.consultaSQLToolStripMenuItem.Text = "Consulta SQL";
            this.consultaSQLToolStripMenuItem.Click += new System.EventHandler(this.consultaSQLToolStripMenuItem_Click);
            // 
            // btnVisualizar
            // 
            this.btnVisualizar.BackColor = System.Drawing.Color.SteelBlue;
            this.btnVisualizar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVisualizar.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisualizar.ForeColor = System.Drawing.Color.White;
            this.btnVisualizar.Location = new System.Drawing.Point(27, 572);
            this.btnVisualizar.Name = "btnVisualizar";
            this.btnVisualizar.Size = new System.Drawing.Size(199, 47);
            this.btnVisualizar.TabIndex = 29;
            this.btnVisualizar.Text = "Visualizar";
            this.btnVisualizar.UseVisualStyleBackColor = false;
            this.btnVisualizar.Click += new System.EventHandler(this.btnVisualizar_Click);
            // 
            // dgvRelaciones
            // 
            this.dgvRelaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRelaciones.Location = new System.Drawing.Point(251, 553);
            this.dgvRelaciones.Name = "dgvRelaciones";
            this.dgvRelaciones.RowHeadersWidth = 51;
            this.dgvRelaciones.RowTemplate.Height = 24;
            this.dgvRelaciones.Size = new System.Drawing.Size(757, 102);
            this.dgvRelaciones.TabIndex = 30;
            // 
            // RelacionTablas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1284, 716);
            this.Controls.Add(this.dgvRelaciones);
            this.Controls.Add(this.btnVisualizar);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btnConfirmar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbLlave2);
            this.Controls.Add(this.cmbLlave1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbTRelacion);
            this.Controls.Add(this.dgvResultados2);
            this.Controls.Add(this.cmbTabla2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvResultados1);
            this.Controls.Add(this.cmbTabla1);
            this.Name = "RelacionTablas";
            this.Text = "RelacionTablas";
            this.Load += new System.EventHandler(this.RelacionTablas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRelaciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbLlave2;
        private System.Windows.Forms.ComboBox cmbLlave1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbTRelacion;
        private System.Windows.Forms.DataGridView dgvResultados2;
        private System.Windows.Forms.ComboBox cmbTabla2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvResultados1;
        private System.Windows.Forms.ComboBox cmbTabla1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem crearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultaSQLToolStripMenuItem;
        private System.Windows.Forms.Button btnVisualizar;
        private System.Windows.Forms.DataGridView dgvRelaciones;
    }
}