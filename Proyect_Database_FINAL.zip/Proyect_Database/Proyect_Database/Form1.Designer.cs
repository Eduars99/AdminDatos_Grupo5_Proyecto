﻿
namespace Proyect_Database
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNombreTabla = new System.Windows.Forms.TextBox();
            this.dvgCampos = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCrearTabla = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.NombreCampo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TipoDato = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.PrimaryKey = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgvNull = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.crearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultaSQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dvgCampos)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNombreTabla
            // 
            this.txtNombreTabla.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.txtNombreTabla.Location = new System.Drawing.Point(187, 164);
            this.txtNombreTabla.Name = "txtNombreTabla";
            this.txtNombreTabla.Size = new System.Drawing.Size(246, 24);
            this.txtNombreTabla.TabIndex = 0;
            // 
            // dvgCampos
            // 
            this.dvgCampos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgCampos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NombreCampo,
            this.TipoDato,
            this.PrimaryKey,
            this.dgvNull});
            this.dvgCampos.Location = new System.Drawing.Point(36, 217);
            this.dvgCampos.Name = "dvgCampos";
            this.dvgCampos.RowHeadersWidth = 51;
            this.dvgCampos.RowTemplate.Height = 24;
            this.dvgCampos.Size = new System.Drawing.Size(682, 312);
            this.dvgCampos.TabIndex = 1;
            this.dvgCampos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvgCampos_CellContentClick);
            this.dvgCampos.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dvgCampos_CellPainting);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(12, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombre de la Tabla";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnCrearTabla
            // 
            this.btnCrearTabla.BackColor = System.Drawing.Color.ForestGreen;
            this.btnCrearTabla.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCrearTabla.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.btnCrearTabla.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCrearTabla.Location = new System.Drawing.Point(464, 153);
            this.btnCrearTabla.Name = "btnCrearTabla";
            this.btnCrearTabla.Size = new System.Drawing.Size(179, 47);
            this.btnCrearTabla.TabIndex = 3;
            this.btnCrearTabla.Text = "Crear Tabla";
            this.btnCrearTabla.UseVisualStyleBackColor = false;
            this.btnCrearTabla.Click += new System.EventHandler(this.btnCrearTabla_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 42.2F);
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(47, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(531, 90);
            this.label2.TabIndex = 18;
            this.label2.Text = "Creacion de Tablas";
            // 
            // NombreCampo
            // 
            this.NombreCampo.HeaderText = "Campos";
            this.NombreCampo.MinimumWidth = 6;
            this.NombreCampo.Name = "NombreCampo";
            this.NombreCampo.Width = 125;
            // 
            // TipoDato
            // 
            this.TipoDato.HeaderText = "Tipo de Datos";
            this.TipoDato.Items.AddRange(new object[] {
            "bigint",
            "binary(50)",
            "bit",
            "char(10)",
            "date",
            "datetime",
            "datetime2(7)",
            "decimal(18,0)",
            "float",
            "geography",
            "geometry",
            "hierarchyid",
            "image",
            "int",
            "money",
            "nchar(10)",
            "ntext",
            "numeric(18,0)",
            "nvarchar(50)",
            "nvarchar(MAX)",
            "real",
            "smalldatetime",
            "smallint",
            "smallmoney",
            "sql_variant",
            "time(7)",
            "timestamp",
            "tinyint",
            "uniqueidentifier",
            "varbinary(50)",
            "varbinary(MAX)",
            "varchar(50)",
            "varchar(MAX)",
            "xml"});
            this.TipoDato.MinimumWidth = 6;
            this.TipoDato.Name = "TipoDato";
            this.TipoDato.Width = 125;
            // 
            // PrimaryKey
            // 
            this.PrimaryKey.HeaderText = "Llave Primaria";
            this.PrimaryKey.MinimumWidth = 6;
            this.PrimaryKey.Name = "PrimaryKey";
            this.PrimaryKey.Width = 125;
            // 
            // dgvNull
            // 
            this.dgvNull.HeaderText = "Allow Null";
            this.dgvNull.MinimumWidth = 6;
            this.dgvNull.Name = "dgvNull";
            this.dgvNull.Width = 125;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Georgia", 10F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.crearToolStripMenuItem,
            this.consultaSQLToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(746, 28);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // crearToolStripMenuItem
            // 
            this.crearToolStripMenuItem.Name = "crearToolStripMenuItem";
            this.crearToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.crearToolStripMenuItem.Text = "Crear Relaciones";
            this.crearToolStripMenuItem.Click += new System.EventHandler(this.crearToolStripMenuItem_Click);
            // 
            // consultaSQLToolStripMenuItem
            // 
            this.consultaSQLToolStripMenuItem.Name = "consultaSQLToolStripMenuItem";
            this.consultaSQLToolStripMenuItem.Size = new System.Drawing.Size(127, 24);
            this.consultaSQLToolStripMenuItem.Text = "Consulta SQL";
            this.consultaSQLToolStripMenuItem.Click += new System.EventHandler(this.consultaSQLToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(746, 541);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCrearTabla);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dvgCampos);
            this.Controls.Add(this.txtNombreTabla);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvgCampos)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNombreTabla;
        private System.Windows.Forms.DataGridView dvgCampos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCrearTabla;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn NombreCampo;
        private System.Windows.Forms.DataGridViewComboBoxColumn TipoDato;
        private System.Windows.Forms.DataGridViewCheckBoxColumn PrimaryKey;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dgvNull;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem crearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultaSQLToolStripMenuItem;
    }
}

