﻿
namespace Proyect_Database
{
    partial class QueryEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvInfo = new System.Windows.Forms.DataGridView();
            this.cmbTablas = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnEjecutar = new System.Windows.Forms.Button();
            this.txtSentenciaSQL = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvInfo
            // 
            this.dgvInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInfo.Location = new System.Drawing.Point(39, 366);
            this.dgvInfo.Name = "dgvInfo";
            this.dgvInfo.RowHeadersWidth = 51;
            this.dgvInfo.RowTemplate.Height = 24;
            this.dgvInfo.Size = new System.Drawing.Size(1018, 129);
            this.dgvInfo.TabIndex = 13;
            // 
            // cmbTablas
            // 
            this.cmbTablas.BackColor = System.Drawing.Color.White;
            this.cmbTablas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmbTablas.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.cmbTablas.ForeColor = System.Drawing.Color.Black;
            this.cmbTablas.FormattingEnabled = true;
            this.cmbTablas.Location = new System.Drawing.Point(183, 132);
            this.cmbTablas.Name = "cmbTablas";
            this.cmbTablas.Size = new System.Drawing.Size(208, 26);
            this.cmbTablas.TabIndex = 12;
            this.cmbTablas.SelectedIndexChanged += new System.EventHandler(this.cmbTablas_SelectedIndexChanged_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(36, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 18);
            this.label2.TabIndex = 11;
            this.label2.Text = "Seleccion de Tabla";
            // 
            // btnEjecutar
            // 
            this.btnEjecutar.BackColor = System.Drawing.Color.ForestGreen;
            this.btnEjecutar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEjecutar.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.btnEjecutar.ForeColor = System.Drawing.Color.Transparent;
            this.btnEjecutar.Location = new System.Drawing.Point(447, 119);
            this.btnEjecutar.Name = "btnEjecutar";
            this.btnEjecutar.Size = new System.Drawing.Size(142, 51);
            this.btnEjecutar.TabIndex = 10;
            this.btnEjecutar.Text = "Ejecutar";
            this.btnEjecutar.UseVisualStyleBackColor = false;
            this.btnEjecutar.Click += new System.EventHandler(this.btnEjecutar_Click);
            // 
            // txtSentenciaSQL
            // 
            this.txtSentenciaSQL.Font = new System.Drawing.Font("Georgia", 8.8F);
            this.txtSentenciaSQL.Location = new System.Drawing.Point(39, 194);
            this.txtSentenciaSQL.Name = "txtSentenciaSQL";
            this.txtSentenciaSQL.Size = new System.Drawing.Size(1018, 129);
            this.txtSentenciaSQL.TabIndex = 9;
            this.txtSentenciaSQL.Text = "";
            this.txtSentenciaSQL.TextChanged += new System.EventHandler(this.txtSentenciaSQL_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 42.2F);
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(789, 90);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ejecucion de Sentencias SQL";
            // 
            // dgvResultados
            // 
            this.dgvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados.Location = new System.Drawing.Point(39, 501);
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.RowHeadersWidth = 51;
            this.dgvResultados.RowTemplate.Height = 24;
            this.dgvResultados.Size = new System.Drawing.Size(1018, 187);
            this.dgvResultados.TabIndex = 14;
            // 
            // QueryEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1082, 742);
            this.Controls.Add(this.dgvResultados);
            this.Controls.Add(this.dgvInfo);
            this.Controls.Add(this.cmbTablas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnEjecutar);
            this.Controls.Add(this.txtSentenciaSQL);
            this.Controls.Add(this.label1);
            this.Name = "QueryEmpleado";
            this.Text = "QueryEmpleado";
            this.Load += new System.EventHandler(this.QueryEmpleado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvInfo;
        private System.Windows.Forms.ComboBox cmbTablas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnEjecutar;
        private System.Windows.Forms.RichTextBox txtSentenciaSQL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvResultados;
    }
}