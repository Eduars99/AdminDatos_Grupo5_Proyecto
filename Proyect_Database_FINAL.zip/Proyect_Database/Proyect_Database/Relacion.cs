﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyect_Database
{
    class Relacion
    {
        public string TablaOrigen { get; set; }
        public string TablaDestino { get; set; }
        public string LlaveForanea { get; set; }
        public string TipoDeRelacion { get; set; }

    }
}
