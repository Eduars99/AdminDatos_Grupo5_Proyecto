﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_Database
{
    public partial class QueryEmpleado : Form
    {
        public QueryEmpleado()
        {
            InitializeComponent();
        }

        private void btnEjecutar_Click(object sender, EventArgs e)
        {
            // Obtener la sentencia SQL del cuadro de texto
            string sentenciaSQL = txtSentenciaSQL.Text.Trim();
            string tablaSeleccionada = cmbTablas.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(sentenciaSQL))
            {
                MessageBox.Show("Por favor, ingresa una sentencia SQL.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Validar comandos restringidos
            string[] comandosRestringidos = { "CREATE TABLE", "DROP", "ALTER" };
            foreach (var comando in comandosRestringidos)
            {
                if (sentenciaSQL.StartsWith(comando, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show($"El comando '{comando}' no está permitido para este usuario.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            try
            {
                using (var context = new TiendaEntities())
                {
                    if (sentenciaSQL.StartsWith("SELECT", StringComparison.OrdinalIgnoreCase))
                    {
                        // Usar un DataTable para cargar los resultados
                        var dataTable = new DataTable();
                        var connection = context.Database.Connection;

                        connection.Open();
                        using (var command = connection.CreateCommand())
                        {
                            command.CommandText = sentenciaSQL;
                            using (var reader = command.ExecuteReader())
                            {
                                dataTable.Load(reader); // Cargar los datos en el DataTable
                            }
                        }
                        connection.Close();

                        // Mostrar los datos en el DataGridView
                        dgvInfo.DataSource = dataTable;
                        MessageBox.Show("Consulta ejecutada exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // Ejecución de otras sentencias SQL
                        int filasAfectadas = context.Database.ExecuteSqlCommand(sentenciaSQL);
                        MessageBox.Show($"Sentencia ejecutada correctamente. Filas afectadas: {filasAfectadas}.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        if (!string.IsNullOrEmpty(tablaSeleccionada))
                        {
                            CargarDatosDeTabla(tablaSeleccionada); // Recargar datos en el DataGridView
                        }
                    }
                }
                txtSentenciaSQL.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }  

        private void QueryEmpleado_Load(object sender, EventArgs e)
        {
            AplicarEstiloDataGridView(dgvResultados);
           AplicarEstiloDataGridView(dgvInfo);
            try
            {
                using (var context = new TiendaEntities()) 
                {
                    // Ejecutar una consulta para obtener los nombres de las tablas en la base de datos
                    var tablas = context.Database.SqlQuery<string>(
                        "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'"
                    ).ToList();

                    // Asignar la lista de tablas al ComboBox
                    cmbTablas.DataSource = tablas;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las tablas: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void AplicarEstiloDataGridView(DataGridView dgv)
        {
            // Estilo general
            dgv.BorderStyle = BorderStyle.None;
            dgv.BackgroundColor = Color.Black;
            dgv.DefaultCellStyle.BackColor = Color.Gray;
            dgv.DefaultCellStyle.ForeColor = Color.White;
            dgv.DefaultCellStyle.Font = new Font("Arial", 10);

            // Encabezados de columna
            dgv.EnableHeadersVisualStyles = false; // Necesario para aplicar estilos personalizados
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Green;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12, FontStyle.Bold);

            // Colores alternativos en las filas
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.DarkGray;

            // Ajustar tamaño de las columnas
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Quitar bordes de celda
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;

            // Ocultar encabezado de filas (opcional)
            dgv.RowHeadersVisible = false;
        }

        private void CargarDatosDeTabla(string nombreTabla)
        {
            try
            {
                using (var context = new TiendaEntities()) 
                {
                    // Crear una consulta dinámica para seleccionar todos los datos de la tabla seleccionada
                    string consultaSQL = $"SELECT * FROM {nombreTabla}";

                    // Ejecutar la consulta y cargar los resultados en un DataTable
                    var dataTable = new DataTable();
                    var connection = context.Database.Connection;

                    connection.Open();
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = consultaSQL;
                        using (var reader = command.ExecuteReader())
                        {
                            dataTable.Load(reader); // Cargar los datos en el DataTable
                        }
                    }
                    connection.Close();

                    // Asignar el DataTable como fuente de datos para el DataGridView
                    dgvResultados.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos de la tabla {nombreTabla}: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbTablas_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obtener el nombre de la tabla seleccionada
            string tablaSeleccionada = cmbTablas.SelectedItem.ToString();

            // Cargar los datos de la tabla seleccionada y mostrarlos en el DataGridView
            CargarDatosDeTabla(tablaSeleccionada);
        }

        private void txtSentenciaSQL_TextChanged(object sender, EventArgs e)
        {
            // Guardar la posición actual del cursor y selección
            int selectionStart = txtSentenciaSQL.SelectionStart;
            int selectionLength = txtSentenciaSQL.SelectionLength;

            // Suspender actualizaciones para evitar parpadeos
            txtSentenciaSQL.SuspendLayout();

            // Restablecer el color de todo el texto a negro
            txtSentenciaSQL.SelectAll();
            txtSentenciaSQL.SelectionColor = Color.Black;

            // Colorear palabras reservadas de SQL en azul
            string[] palabrasReservadasSQL = {
        "SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE", "INNER JOIN",
        "LEFT JOIN", "RIGHT JOIN", "FULL JOIN", "GROUP BY", "ORDER BY", "HAVING",
        "AS", "DISTINCT", "TOP", "LIMIT", "OFFSET", "VALUES", "INTO",
        "CREATE", "TABLE", "DROP", "ALTER", "VIEW", "INDEX", "PRIMARY KEY",
        "FOREIGN KEY", "REFERENCES", "NOT NULL", "DEFAULT", "AND", "OR", "LIKE",
        "IN", "IS NULL", "BETWEEN", "EXISTS"
    };

            foreach (var palabra in palabrasReservadasSQL)
            {
                ResaltarPalabra(palabra, Color.Blue);
            }

            // Colorear comentarios en verde
            ResaltarComentarios(Color.Green);

            // Restaurar la posición del cursor
            txtSentenciaSQL.Select(selectionStart, selectionLength);
            txtSentenciaSQL.SelectionColor = txtSentenciaSQL.ForeColor;

            // Reanudar actualizaciones
            txtSentenciaSQL.ResumeLayout();
        }
        private void ResaltarPalabra(string palabra, Color color)
        {
            int startIndex = 0;
            string text = txtSentenciaSQL.Text;

            while ((startIndex = text.IndexOf(palabra, startIndex, StringComparison.OrdinalIgnoreCase)) != -1)
            {
                bool isStartValid = (startIndex == 0 || !char.IsLetterOrDigit(text[startIndex - 1]));
                bool isEndValid = (startIndex + palabra.Length == text.Length || !char.IsLetterOrDigit(text[startIndex + palabra.Length]));

                if (isStartValid && isEndValid)
                {
                    txtSentenciaSQL.Select(startIndex, palabra.Length);
                    txtSentenciaSQL.SelectionColor = color;
                }

                startIndex += palabra.Length;
            }
        }

        private void ResaltarComentarios(Color color)
        {
            string text = txtSentenciaSQL.Text;
            int startIndex = 0;

            while ((startIndex = text.IndexOf("--", startIndex)) != -1)
            {
                int endIndex = text.IndexOf("\n", startIndex);
                if (endIndex == -1) endIndex = text.Length;

                txtSentenciaSQL.Select(startIndex, endIndex - startIndex);
                txtSentenciaSQL.SelectionColor = color;

                startIndex = endIndex;
            }
        }

        private void cmbTablas_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Obtener el nombre de la tabla seleccionada
            string tablaSeleccionada = cmbTablas.SelectedItem.ToString();

            // Cargar los datos de la tabla seleccionada y mostrarlos en el DataGridView
            CargarDatosDeTabla(tablaSeleccionada);
        }
    }
}
