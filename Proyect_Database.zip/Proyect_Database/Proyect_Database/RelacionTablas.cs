﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyect_Database
{
    public partial class RelacionTablas : Form
    {
        public RelacionTablas()
        {
            InitializeComponent();
        }

       

        private void CargarDatosDeTabla(string nombreTabla, DataGridView dataGridView)
        {
            try
            {
                using (var context = new TiendaEntities())
                {
                    // Consulta para obtener datos de la tabla
                    string consultaSQL = $"SELECT * FROM {nombreTabla}";
                    var dataTable = new DataTable();
                    var connection = context.Database.Connection;

                    connection.Open();
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = consultaSQL;
                        using (var reader = command.ExecuteReader())
                        {
                            dataTable.Load(reader);
                        }
                    }
                    connection.Close();

                    // Asignar los datos al DataGridView correspondiente
                    dataGridView.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos de la tabla {nombreTabla}: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarColumnasDeTabla(string nombreTabla, ComboBox comboBoxLlave)
        {
            try
            {
                using (var context = new TiendaEntities())
                {
                    // Consulta para obtener todas las columnas de la tabla
                    string consultaSQL = $@"
                SELECT COLUMN_NAME
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = '{nombreTabla}'";

                    var columnas = context.Database.SqlQuery<string>(consultaSQL).ToList();

                    // Asignar las columnas al ComboBox correspondiente
                    comboBoxLlave.DataSource = new List<string>(columnas);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las columnas de la tabla: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new TiendaEntities())
                {
                    // Obtener las tablas seleccionadas
                    string tabla1 = cmbTabla1.SelectedItem.ToString();
                    string tabla2 = cmbTabla2.SelectedItem.ToString();
                    string tipoRelacion = cmbTRelacion.SelectedItem.ToString();

                    // Obtener las claves primarias seleccionadas en los ComboBox de llaves
                    string clavePrimaria1 = cmbLlave1.SelectedItem.ToString(); // Clave primaria de la primera tabla
                    string clavePrimaria2 = cmbLlave2.SelectedItem.ToString(); // Clave primaria de la segunda tabla


                    string consultaValidacion = $@"
                SELECT COUNT(*)
                FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS RC
                JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC1 ON RC.CONSTRAINT_NAME = TC1.CONSTRAINT_NAME
                JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC2 ON RC.UNIQUE_CONSTRAINT_NAME = TC2.CONSTRAINT_NAME
                WHERE TC1.TABLE_NAME = '{tabla2}' AND TC2.TABLE_NAME = '{tabla1}'";

                    int relacionesExistentes = context.Database.SqlQuery<int>(consultaValidacion).FirstOrDefault();

                    if (relacionesExistentes > 0)
                    {
                        MessageBox.Show("Ya existe una relación entre estas tablas.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }


                    string query = string.Empty;

                    switch (tipoRelacion)
                    {
                        case "1:1":
                            // Para una relación 1:1, usaremos UNIQUE en la clave foránea.
                            query = $@"
                        ALTER TABLE {tabla1} 
                        ADD CONSTRAINT FK_{tabla1}_{tabla2} 
                        FOREIGN KEY ({clavePrimaria2}) 
                        REFERENCES {tabla2}({clavePrimaria2})";
                            break;

                        case "1:N":
                            // Para una relación 1:N, la clave foránea estará en la tabla "muchos" (tabla2).
                            query = $@"
                        ALTER TABLE {tabla2} 
                        ADD CONSTRAINT FK_{tabla2}_{tabla1} 
                        FOREIGN KEY ({clavePrimaria1}) 
                        REFERENCES {tabla1}({clavePrimaria1})";
                            break;

                        case "N:M":
                            // Para una relación M:M, necesitas crear una tabla intermedia (por ejemplo, Tabla1_Tabla2).
                            string tablaIntermedia = $"{tabla1}_{tabla2}";
                            query = $@"
                        CREATE TABLE {tablaIntermedia} (
                            {clavePrimaria1} INT,
                            {clavePrimaria2} INT,
                            PRIMARY KEY ({clavePrimaria1}, {clavePrimaria2}),
                            FOREIGN KEY ({clavePrimaria1}) REFERENCES {tabla1}({clavePrimaria1}),
                            FOREIGN KEY ({clavePrimaria2}) REFERENCES {tabla2}({clavePrimaria2})
                        )";
                            break;

                        default:
                            MessageBox.Show("Seleccione un tipo de relación válido.");
                            return;
                    }

                    // Ejecutar el query para crear la relación
                    context.Database.ExecuteSqlCommand(query);
                    MessageBox.Show("Relación creada con éxito.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear la relación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbTabla1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tablaSeleccionada = cmbTabla1.SelectedItem.ToString();
            CargarDatosDeTabla(tablaSeleccionada, dgvResultados1);  // Mostrar los datos de la tabla seleccionada en el primer DataGrid
            CargarColumnasDeTabla(tablaSeleccionada, cmbLlave1);  // Cargar las columnas de la t
        }

        private void cmbTabla2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tablaSeleccionada = cmbTabla2.SelectedItem.ToString();
            CargarDatosDeTabla(tablaSeleccionada, dgvResultados2);  // Mostrar los datos de la tabla seleccionada en el segundo DataGrid
            CargarColumnasDeTabla(tablaSeleccionada, cmbLlave2);  // Cargar las columnas de la tabla en el ComboBox de llaves de la segunda tabla
        }

        private void RelacionTablas_Load(object sender, EventArgs e)
        {
            try
            {
                using (var context = new TiendaEntities())
                {
                    var tablas = context.Database.SqlQuery<string>
                    (
                        "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'"
                    ).ToList();
                    cmbTabla1.DataSource = new List<string>(tablas);
                    cmbTabla2.DataSource = new List<string>(tablas);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las tablas: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
