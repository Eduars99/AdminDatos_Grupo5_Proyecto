﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace Proyect_Database
{
    public partial class DiagramaTablas : Form
    {

        private GroupBox tablaSeleccionada = null;
        private Point mouseOffset;
        private bool isDragging = false; // Flag para saber si se está arrastrando
        public DiagramaTablas()
        {
            InitializeComponent();
        }


        // Obtener tablas y relaciones de la base de datos
        private Dictionary<string, List<string>> ObtenerTablasYRelaciones()
        {
            using (var context = new TiendaEntities())
            {
                // Obtener las tablas desde INFORMATION_SCHEMA
                var tablas = context.Database.SqlQuery<string>(
                    "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'"
                ).ToList();

                var datos = new Dictionary<string, List<string>>();

                // Obtener las columnas para cada tabla
                foreach (var tabla in tablas)
                {
                    var columnas = context.Database.SqlQuery<string>(
                        $@"SELECT COLUMN_NAME
                           FROM INFORMATION_SCHEMA.COLUMNS
                           WHERE TABLE_NAME = '{tabla}'"
                    ).ToList();
                    datos.Add(tabla, columnas);
                }

                return datos;
            }
        }

        private void GenerarDiagrama()
        {
            try
            {
                // Limpiar controles anteriores
                panelDiagram.Controls.Clear();

                // Obtener tablas, columnas y relaciones
                var tablasYRelaciones = ObtenerTablasYRelaciones();

                int x = 20, y = 20; // Posiciones iniciales para los grupos
                int offsetX = 250, offsetY = 150; // Espaciado entre grupos

                foreach (var tabla in tablasYRelaciones)
                {
                    var groupBox = new GroupBox
                    {
                        Text = tabla.Key, // Nombre de la tabla
                        Size = new Size(180, 120), // Tamaño del GroupBox
                        Location = new Point(x, y) // Ubicación en el panel
                    };

                    var listBox = new ListBox
                    {
                        DataSource = tabla.Value, // Asignar las columnas
                        Dock = DockStyle.Fill
                    };

                    groupBox.Controls.Add(listBox);
                    groupBox.MouseDown += GroupBox_MouseDown;
                    groupBox.MouseMove += GroupBox_MouseMove;
                    groupBox.MouseUp += GroupBox_MouseUp;

                    panelDiagram.Controls.Add(groupBox);

                    x += offsetX;
                    if (x + offsetX > panelDiagram.Width)
                    {
                        x = 20;
                        y += offsetY;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al generar el diagrama: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Evento MouseDown: Capturar tabla seleccionada y posición del mouse
        private void GroupBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                tablaSeleccionada = sender as GroupBox;
                mouseOffset = new Point(e.X, e.Y);
                isDragging = true;  
            }
        }

        // Evento MouseMove: Mover el GroupBox
        private void GroupBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging && tablaSeleccionada != null)
            {
                var newX = tablaSeleccionada.Location.X + e.X - mouseOffset.X;
                var newY = tablaSeleccionada.Location.Y + e.Y - mouseOffset.Y;
                tablaSeleccionada.Location = new Point(newX, newY);
            }
        }

        // Evento MouseUp: Finalizar el arrastre
        private void GroupBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
                tablaSeleccionada = null;
            }
        }

        private void panelDiagram_Paint(object sender, PaintEventArgs e)
        {
            

        }

        private void DiagramaTablas_Load(object sender, EventArgs e)
        {
            GenerarDiagrama();
        }
    }
}
