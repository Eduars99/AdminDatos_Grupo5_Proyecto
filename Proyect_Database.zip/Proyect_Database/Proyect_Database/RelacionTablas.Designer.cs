﻿
namespace Proyect_Database
{
    partial class RelacionTablas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbLlave2 = new System.Windows.Forms.ComboBox();
            this.cmbLlave1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbTRelacion = new System.Windows.Forms.ComboBox();
            this.dgvResultados2 = new System.Windows.Forms.DataGridView();
            this.cmbTabla2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvResultados1 = new System.Windows.Forms.DataGridView();
            this.cmbTabla1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.Location = new System.Drawing.Point(829, 371);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(146, 80);
            this.btnConfirmar.TabIndex = 27;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = true;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(313, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 17);
            this.label6.TabIndex = 26;
            this.label6.Text = "Llave Foranea";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(313, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 17);
            this.label5.TabIndex = 25;
            this.label5.Text = "Llave Primaria";
            // 
            // cmbLlave2
            // 
            this.cmbLlave2.FormattingEnabled = true;
            this.cmbLlave2.Location = new System.Drawing.Point(431, 267);
            this.cmbLlave2.Name = "cmbLlave2";
            this.cmbLlave2.Size = new System.Drawing.Size(188, 24);
            this.cmbLlave2.TabIndex = 24;
            // 
            // cmbLlave1
            // 
            this.cmbLlave1.FormattingEnabled = true;
            this.cmbLlave1.Location = new System.Drawing.Point(438, 87);
            this.cmbLlave1.Name = "cmbLlave1";
            this.cmbLlave1.Size = new System.Drawing.Size(188, 24);
            this.cmbLlave1.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(709, 294);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 17);
            this.label4.TabIndex = 22;
            this.label4.Text = "Tipo de Relación:";
            // 
            // cmbTRelacion
            // 
            this.cmbTRelacion.FormattingEnabled = true;
            this.cmbTRelacion.Items.AddRange(new object[] {
            "1:1",
            "1:N",
            "M:M"});
            this.cmbTRelacion.Location = new System.Drawing.Point(829, 291);
            this.cmbTRelacion.Name = "cmbTRelacion";
            this.cmbTRelacion.Size = new System.Drawing.Size(188, 24);
            this.cmbTRelacion.TabIndex = 21;
            // 
            // dgvResultados2
            // 
            this.dgvResultados2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados2.Location = new System.Drawing.Point(49, 300);
            this.dgvResultados2.Name = "dgvResultados2";
            this.dgvResultados2.RowHeadersWidth = 51;
            this.dgvResultados2.RowTemplate.Height = 24;
            this.dgvResultados2.Size = new System.Drawing.Size(577, 133);
            this.dgvResultados2.TabIndex = 20;
            // 
            // cmbTabla2
            // 
            this.cmbTabla2.FormattingEnabled = true;
            this.cmbTabla2.Location = new System.Drawing.Point(108, 269);
            this.cmbTabla2.Name = "cmbTabla2";
            this.cmbTabla2.Size = new System.Drawing.Size(188, 24);
            this.cmbTabla2.TabIndex = 19;
            this.cmbTabla2.SelectedIndexChanged += new System.EventHandler(this.cmbTabla2_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "Tabla 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 17;
            this.label2.Text = "Tabla 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 25);
            this.label1.TabIndex = 16;
            this.label1.Text = "Relación entre Tablas";
            // 
            // dgvResultados1
            // 
            this.dgvResultados1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados1.Location = new System.Drawing.Point(52, 117);
            this.dgvResultados1.Name = "dgvResultados1";
            this.dgvResultados1.RowHeadersWidth = 51;
            this.dgvResultados1.RowTemplate.Height = 24;
            this.dgvResultados1.Size = new System.Drawing.Size(574, 133);
            this.dgvResultados1.TabIndex = 15;
            // 
            // cmbTabla1
            // 
            this.cmbTabla1.FormattingEnabled = true;
            this.cmbTabla1.Location = new System.Drawing.Point(108, 87);
            this.cmbTabla1.Name = "cmbTabla1";
            this.cmbTabla1.Size = new System.Drawing.Size(188, 24);
            this.cmbTabla1.TabIndex = 14;
            this.cmbTabla1.SelectedIndexChanged += new System.EventHandler(this.cmbTabla1_SelectedIndexChanged);
            // 
            // RelacionTablas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1069, 510);
            this.Controls.Add(this.btnConfirmar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbLlave2);
            this.Controls.Add(this.cmbLlave1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbTRelacion);
            this.Controls.Add(this.dgvResultados2);
            this.Controls.Add(this.cmbTabla2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvResultados1);
            this.Controls.Add(this.cmbTabla1);
            this.Name = "RelacionTablas";
            this.Text = "RelacionTablas";
            this.Load += new System.EventHandler(this.RelacionTablas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbLlave2;
        private System.Windows.Forms.ComboBox cmbLlave1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbTRelacion;
        private System.Windows.Forms.DataGridView dgvResultados2;
        private System.Windows.Forms.ComboBox cmbTabla2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvResultados1;
        private System.Windows.Forms.ComboBox cmbTabla1;
    }
}